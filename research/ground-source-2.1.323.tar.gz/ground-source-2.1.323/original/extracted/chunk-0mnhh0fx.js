// @bun @bytecode
// (c) Anthropic PBC. All rights reserved. Use is subject to the Legal Agreements outlined here: https://code.claude.com/docs/en/legal-and-compliance.

// Version: 2.1.323
import{Le}from"/$bunfs/root/chunk-0qyb3r5p.js";import{W}from"/$bunfs/root/chunk-1zs6h7k0.js";import{ue}from"/$bunfs/root/chunk-zart1qwz.js";var F=new W(()=>Le());var B=ue({hasRoomForTabs:!1},(e)=>{e.hasRoomForTabs=!1});
