// @bun @bytecode
// (c) Anthropic PBC. All rights reserved. Use is subject to the Legal Agreements outlined here: https://code.claude.com/docs/en/legal-and-compliance.

// Version: 2.1.323
import{a}from"/$bunfs/root/chunk-zfpk8qec.js";import{we}from"/$bunfs/root/chunk-qxb2gr8e.js";import{xp}from"/$bunfs/root/chunk-c39a0cpy.js";import{hve,zPo,Hb}from"/$bunfs/root/chunk-5wk9qwkf.js";function Wdn(){let r=!1;try{r=xp()}catch(o){a(o)}try{return(r||hve())&&zPo()}catch(o){return a(o),!0}}function NS(){if(!Wdn())return!1;try{return Hb()==="unanswered"}catch(r){return a(r),!0}}function jjt(){try{we().organizationAsk.hasHeld=!0}catch(r){a(r)}}export{Wdn,NS,jjt};
