// @bun @bytecode
// (c) Anthropic PBC. All rights reserved. Use is subject to the Legal Agreements outlined here: https://code.claude.com/docs/en/legal-and-compliance.

// Version: 2.1.323
import{CFt,fAs}from"/$bunfs/root/chunk-r3aa0q5g.js";import{N}from"/$bunfs/root/chunk-qb4yqgcv.js";import{tn}from"/$bunfs/root/chunk-qxb2gr8e.js";import{a}from"/$bunfs/root/chunk-zfpk8qec.js";import{MMe,dF}from"/$bunfs/root/chunk-y2bfr1vh.js";function Klr(e){let o=e.trim();return o!==""&&!o.startsWith("/")}var BZo=()=>!1;var jZo=()=>dF()&&!MMe()&&tn("tengu_quiet_ember",BZo());var Ylr={name:"cc-plugin-responsive-mode",description:"Responsive mode: Claude replies to you in a sentence before thinking or using tools, on every prompt",isAvailable:jZo,defaultEnabled:!1};function Teo({text:e,pastedContents:o,isSentByPerson:t,wait:r}){if(!t||r||!Klr(e))return!1;try{return fAs(e,o).length===0&&CFt(Ylr.name)}catch(i){return a(N(i)),!1}}
export{Klr,BZo,jZo,Ylr,Teo};
