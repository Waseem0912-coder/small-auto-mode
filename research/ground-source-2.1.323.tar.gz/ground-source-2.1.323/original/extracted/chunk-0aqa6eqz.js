// @bun @bytecode
// (c) Anthropic PBC. All rights reserved. Use is subject to the Legal Agreements outlined here: https://code.claude.com/docs/en/legal-and-compliance.

// Version: 2.1.323
import{GWt}from"/$bunfs/root/chunk-stjwya8s.js";var H="/$bunfs/root/hljsBundle.generated.min.js";function L(){return GWt(H,import.meta.dirname)}export{L as loadHljsBundleJs};
