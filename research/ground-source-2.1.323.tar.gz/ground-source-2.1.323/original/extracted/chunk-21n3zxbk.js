// @bun @bytecode
// (c) Anthropic PBC. All rights reserved. Use is subject to the Legal Agreements outlined here: https://code.claude.com/docs/en/legal-and-compliance.

// Version: 2.1.323
import{zs}from"/$bunfs/root/chunk-c39a0cpy.js";import{Lvt,Dx,LKn}from"/$bunfs/root/chunk-xwwv148t.js";import{Tr}from"/$bunfs/root/chunk-d3ymdvmz.js";var ODe="cc-plugin-you-should-know";var Feo={id:"you-should-know-plugin",providerAgnostic:!0,advertisedCommand:"plugin",cooldownSessions:10,maxLifetimeShows:3,content:async(o)=>`Want a side agent watching your back while Claude works? Turn on You should know:
${Tr("suggestion",o.theme)(`/plugin enable ${ODe}@${zs}`)}`,isRelevant:async()=>Lvt(ODe)&&Dx(ODe)?.defaultEnabled===!1&&LKn(`${ODe}@${zs}`)===void 0};export{ODe,Feo};
