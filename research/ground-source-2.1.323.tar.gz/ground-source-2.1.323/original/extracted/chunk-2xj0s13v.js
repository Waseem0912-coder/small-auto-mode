// @bun @bytecode
// (c) Anthropic PBC. All rights reserved. Use is subject to the Legal Agreements outlined here: https://code.claude.com/docs/en/legal-and-compliance.

// Version: 2.1.323
import{Sn,Bde,sc}from"/$bunfs/root/chunk-ft147hxb.js";export{sc as heldUntilExit,Sn as isTerminalShutdown,Bde as latchTerminalShutdown};
