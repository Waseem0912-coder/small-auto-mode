// @bun @bytecode
// (c) Anthropic PBC. All rights reserved. Use is subject to the Legal Agreements outlined here: https://code.claude.com/docs/en/legal-and-compliance.

// Version: 2.1.323
import{Rje}from"/$bunfs/root/chunk-4ft83sw6.js";import{D}from"/$bunfs/root/chunk-09hdecqv.js";var EN=D(function(s){var r=Rje(),o=(e)=>e[r.SMITHY_CONTEXT_KEY]||(e[r.SMITHY_CONTEXT_KEY]={}),i=(e)=>{if(typeof e==="function")return e;let t=Promise.resolve(e);return()=>t};s.getSmithyContext=o;s.normalizeProvider=i});
export{EN};
