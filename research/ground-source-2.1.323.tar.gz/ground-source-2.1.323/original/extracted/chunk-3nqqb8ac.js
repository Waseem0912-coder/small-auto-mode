// @bun @bytecode
// (c) Anthropic PBC. All rights reserved. Use is subject to the Legal Agreements outlined here: https://code.claude.com/docs/en/legal-and-compliance.

// Version: 2.1.323
import{mo}from"/$bunfs/root/chunk-s67bjq59.js";import{Y}from"/$bunfs/root/chunk-djfsan4s.js";import{W}from"/$bunfs/root/chunk-1zs6h7k0.js";async function W9(){try{let s=t();if(s.length>0)await Promise.race([Promise.allSettled(s),Y(200)]),s.length=0;let[{settle1PEventLoggingBeforeExit:e,shutdown1PEventLogging:r},{shutdownDatadog:n},{shutdownErrorTracking:a}]=await Promise.all([import("/$bunfs/root/chunk-m584atf5.js"),import("/$bunfs/root/chunk-tbm0keje.js"),import("/$bunfs/root/chunk-7ax9967b.js")]),i=e(),c=[r(),n(),a()];await Promise.race([Promise.all(c),Y(500)]),await i}catch{}}class o{tasks=[]}var u=new W(()=>new o);function t(){return mo(u).tasks}function s2s(s){t().push(s.catch(()=>{}))}
export{W9,s2s};
