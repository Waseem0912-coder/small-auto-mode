// @bun @bytecode
// (c) Anthropic PBC. All rights reserved. Use is subject to the Legal Agreements outlined here: https://code.claude.com/docs/en/legal-and-compliance.

// Version: 2.1.323
import{eeo,teo,vZo}from"/$bunfs/root/chunk-h46p35fq.js";import"/$bunfs/root/chunk-xbvp5g1t.js";export{eeo as COMPOSE_TITLE,teo as composeSubtitle,vZo as continueInProjectsComposeDialog};
