// @bun @bytecode
// (c) Anthropic PBC. All rights reserved. Use is subject to the Legal Agreements outlined here: https://code.claude.com/docs/en/legal-and-compliance.

// Version: 2.1.323
import{ls}from"/$bunfs/root/chunk-s67bjq59.js";import{nl}from"/$bunfs/root/chunk-hxy2bwbn.js";import{HZs,Bjo}from"/$bunfs/root/chunk-6xfvfh95.js";import{a}from"/$bunfs/root/chunk-zfpk8qec.js";import{pva}from"/$bunfs/root/chunk-ft147hxb.js";import{L}from"/$bunfs/root/chunk-cvff4m74.js";async function bOo(r){let e=L([ls(),nl()]).filter((t)=>t!==null);for(let t of e)try{let o=await HZs(r,t);if(o!==void 0){let i=await pva(t,o.gitRoot,r);if(typeof i==="string")Bjo(i,o.gitRoot,o.canonicalRoot)}}catch(o){a(o)}}
export{bOo};
