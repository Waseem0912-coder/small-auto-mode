// @bun @bytecode
// (c) Anthropic PBC. All rights reserved. Use is subject to the Legal Agreements outlined here: https://code.claude.com/docs/en/legal-and-compliance.

// Version: 2.1.323
import{Z}from"/$bunfs/root/chunk-13w6644x.js";import{Js}from"/$bunfs/root/chunk-ft147hxb.js";function UYe(n){return n.replace(/[\r\n\u2028\u2029]+/g," ")}function BYe(n,r){let e=Js(n);if(e.length<=r)return e;let t=Z(e,r),o=Array.from(e.slice(t.length)).length;return`${t} \u2026 (${o} more characters follow that are NOT shown in this message)`}
export{UYe,BYe};
