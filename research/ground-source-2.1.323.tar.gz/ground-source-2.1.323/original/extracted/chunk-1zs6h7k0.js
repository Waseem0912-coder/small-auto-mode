// @bun @bytecode
// (c) Anthropic PBC. All rights reserved. Use is subject to the Legal Agreements outlined here: https://code.claude.com/docs/en/legal-and-compliance.

// Version: 2.1.323
class W{#t;#e=new WeakMap;constructor(t){this.#t=t}of(t){let e=this.#e.get(t);if(e!==void 0)return e;let s=this.#t();return this.#e.set(t,s),s}}
export{W};
