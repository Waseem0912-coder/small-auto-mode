// @bun @bytecode
// (c) Anthropic PBC. All rights reserved. Use is subject to the Legal Agreements outlined here: https://code.claude.com/docs/en/legal-and-compliance.

// Version: 2.1.323
import{Tke}from"/$bunfs/root/chunk-qxb2gr8e.js";import{Qz}from"/$bunfs/root/chunk-ft147hxb.js";import{vJ,Wyt}from"/$bunfs/root/chunk-7x8yvfjs.js";import{kHe}from"/$bunfs/root/chunk-579w43z0.js";function fui(i){let n="client_platform"in i?i.client_platform:void 0;return!(Tke("origin"in i?i.origin:void 0,"isSynthetic"in i&&Boolean(i.isSynthetic))||("is_meta"in i)&&i.is_meta===!0||("seeded_summon"in i)&&i.seeded_summon===!0||("client_composed"in i)&&i.client_composed===!0||("inbound_origin"in i)&&i.inbound_origin!==void 0||n!==void 0&&!(typeof n==="string"&&(vJ(n)||Wyt(n)))||Qz(i)||kHe("initiator"in i&&typeof i.initiator==="string"?i.initiator:void 0)!==void 0)}
export{fui};
