// @bun @bytecode
// (c) Anthropic PBC. All rights reserved. Use is subject to the Legal Agreements outlined here: https://code.claude.com/docs/en/legal-and-compliance.

// Version: 2.1.323
import{we}from"/$bunfs/root/chunk-qxb2gr8e.js";import{oBr}from"/$bunfs/root/chunk-ncw949wx.js";import{A3}from"/$bunfs/root/chunk-6wqev58c.js";import{To}from"/$bunfs/root/chunk-k7ecs2xs.js";var NIo=To();var FIo=To();function Of(o){let t=we().admissionText;if((o.judgedUnder??null)===t)return!0;let r=o.args.pluginStorageId;return A3(r)||o.args.sealed===!0&&FIo.get()?.(r)===!0||!oBr(r,NIo.get()?.()??null)}export{NIo,FIo,Of};
