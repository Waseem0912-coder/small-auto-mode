// @bun @bytecode
// (c) Anthropic PBC. All rights reserved. Use is subject to the Legal Agreements outlined here: https://code.claude.com/docs/en/legal-and-compliance.

// Version: 2.1.323
function o4t(n){return n.includes("microsoft")||n.includes("wsl")}
export{o4t};
