// @bun @bytecode
// (c) Anthropic PBC. All rights reserved. Use is subject to the Legal Agreements outlined here: https://code.claude.com/docs/en/legal-and-compliance.

// Version: 2.1.323
import{Qi,i5,df}from"/$bunfs/root/chunk-mey1bffc.js";async function dvn(s,i){if(await i5()===Qi)return{cleared:!1,reason:"credential_store_failed"};let c=import.meta.require("/$bunfs/root/chunk-fjw261z7.js").mcpAuthModule(),t=new Set,e={cleared:!0};for(let r of i){if(r.type!=="http"&&r.type!=="sse")continue;let a=df(s,r);if(t.has(a))continue;t.add(a);let o=await c.revokeServerTokens(s,r);if(!o.cleared&&(e.cleared||o.reason==="credential_store_failed"))e=o}if(!e.cleared&&e.reason==="credential_store_failed")return e;let n=await i5();if(n===Qi||[...t].some((r)=>!!n?.mcpOAuth?.[r]))return{cleared:!1,reason:"credential_store_failed"};return e}
export{dvn};
