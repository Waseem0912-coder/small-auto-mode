// @bun @bytecode
// (c) Anthropic PBC. All rights reserved. Use is subject to the Legal Agreements outlined here: https://code.claude.com/docs/en/legal-and-compliance.

// Version: 2.1.323
import{v}from"/$bunfs/root/chunk-sy4f915e.js";import{s}from"/$bunfs/root/chunk-cypymn6c.js";import{e}from"/$bunfs/root/chunk-acvj0j80.js";function ws(K){let w=v(8),{onKeyDown:o,onPaste:t,flexDirection:p,gap:n,tabIndex:d,autoFocus:u,children:a}=K,r=p===void 0?"column":p,c=d===void 0?0:d,i=u===void 0?!0:u,y;if(w[0]!==i||w[1]!==a||w[2]!==r||w[3]!==n||w[4]!==o||w[5]!==t||w[6]!==c)y=e(s,{flexDirection:r,gap:n,tabIndex:c,autoFocus:i,onKeyDown:o,onPaste:t,children:a}),w[0]=i,w[1]=a,w[2]=r,w[3]=n,w[4]=o,w[5]=t,w[6]=c,w[7]=y;else y=w[7];return y}
export{ws};
