// @bun @bytecode
// (c) Anthropic PBC. All rights reserved. Use is subject to the Legal Agreements outlined here: https://code.claude.com/docs/en/legal-and-compliance.

// Version: 2.1.323
import{D,Ge}from"/$bunfs/root/chunk-09hdecqv.js";var nzs=D(function(L,H){H.exports=Ge("/$bunfs/root/audio-capture.node")});
export{nzs};
