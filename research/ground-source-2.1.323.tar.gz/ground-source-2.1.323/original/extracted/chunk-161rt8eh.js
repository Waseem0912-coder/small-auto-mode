// @bun @bytecode
// (c) Anthropic PBC. All rights reserved. Use is subject to the Legal Agreements outlined here: https://code.claude.com/docs/en/legal-and-compliance.

// Version: 2.1.323
function UIe(n,e,t){if(typeof t!=="function")return;Object.defineProperty(n,e,{get:t,enumerable:!0,configurable:!0})}function J1r(n,e,t){if(typeof t!=="function")return;Object.defineProperty(n,e,{get:t,enumerable:!0,configurable:!0})}function Q1r(n,e){if(typeof e!=="function")return;Object.defineProperty(n,"policyGate",{get:e,enumerable:!0,configurable:!0})}
export{UIe,J1r,Q1r};
