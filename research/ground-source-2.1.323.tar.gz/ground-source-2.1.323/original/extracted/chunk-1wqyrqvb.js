// @bun @bytecode
// (c) Anthropic PBC. All rights reserved. Use is subject to the Legal Agreements outlined here: https://code.claude.com/docs/en/legal-and-compliance.

// Version: 2.1.323
import{bUo}from"/$bunfs/root/chunk-j8qm7ap9.js";import{m5e}from"/$bunfs/root/chunk-0ksfdb0y.js";import{Aqt}from"/$bunfs/root/chunk-c39a0cpy.js";var{ceil:i,max:a}=Math;function m(t,e,r){if(r?Aqt(t,e,r):e===void 0)e=1;else e=a(bUo(e),0);var n=t==null?0:t.length;if(!n||e<1)return[];var l=0,f=0,o=Array(i(n/e));while(l<n)o[f++]=m5e(t,l,l+=e);return o}var qGe=m;
export{qGe};
