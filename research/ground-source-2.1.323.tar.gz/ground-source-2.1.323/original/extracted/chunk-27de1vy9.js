// @bun @bytecode
// (c) Anthropic PBC. All rights reserved. Use is subject to the Legal Agreements outlined here: https://code.claude.com/docs/en/legal-and-compliance.

// Version: 2.1.323
import{f}from"/$bunfs/root/chunk-er9ga5ee.js";import{d}from"/$bunfs/root/chunk-qb4yqgcv.js";import{Me}from"/$bunfs/root/chunk-qxb2gr8e.js";import{t}from"/$bunfs/root/chunk-jw9em5g5.js";import{Fr}from"/$bunfs/root/chunk-dr8ta7k0.js";async function act(o,r,n){try{await Promise.all([Me((e)=>e.managedSettingsNoticeSeenOrg===o?e:{...e,managedSettingsNoticeSeenOrg:o},n),Fr("remote_managed_settings_login_notice",{surface:f(r)})])}catch(e){t(`managed settings notice: not recorded as shown: ${d(e)}`,{level:"error"})}}
export{act};
