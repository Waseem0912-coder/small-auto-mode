// @bun @bytecode
// (c) Anthropic PBC. All rights reserved. Use is subject to the Legal Agreements outlined here: https://code.claude.com/docs/en/legal-and-compliance.

// Version: 2.1.323
var JRs=/[\p{Cc}\p{Cf}\p{Zl}\p{Zp}\p{Default_Ignorable_Code_Point}\u2800]|(?!\u0020)\p{Zs}/u;var t=new RegExp(`${JRs.source}|\\p{Cs}`,"u"),s=new RegExp(t.source,"gu");function NP(n){return t.test(n)}function yFe(n,e){return n.split(/\r?\n/).some(NP)?`${e} is not shown here because it holds hidden or control characters`:n}function l0(n){return NP(n)?"a path not shown here because it holds hidden or control characters":n}
export{JRs,NP,yFe,l0};
