// @bun @bytecode
// (c) Anthropic PBC. All rights reserved. Use is subject to the Legal Agreements outlined here: https://code.claude.com/docs/en/legal-and-compliance.

// Version: 2.1.323
import{qS,uTa,Jge}from"/$bunfs/root/chunk-mh1dhafb.js";import{i}from"/$bunfs/root/chunk-3nae1zmb.js";import{bt}from"/$bunfs/root/chunk-59sqgzfc.js";import{aBr}from"/$bunfs/root/chunk-w1zfdv37.js";function pQ(e){return i.CLAUDE_CODE_DISABLE_BUNDLED_SKILLS||(e??bt()).disableBundledSkills===!0}var $Do="allow_bundled_skills";function Xrt(){return!qS($Do)}function n(){return uTa()??aBr}function Y9(e){return Xrt()&&!n().includes(e)}function ske(e,t){return pQ(t)||Y9(e)}function Fha(){return Jge($Do,"Bundled skills","are")}function Z1r(e){let t=Xrt();return`${pQ(e)}:${t}:${t?n().join(","):""}`}function UDo(e,t){return e.type==="prompt"&&e.source==="builtin"&&ske(e.name,t)}
export{pQ,$Do,Xrt,Y9,ske,Fha,Z1r,UDo};
