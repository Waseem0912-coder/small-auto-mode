// @bun @bytecode
// (c) Anthropic PBC. All rights reserved. Use is subject to the Legal Agreements outlined here: https://code.claude.com/docs/en/legal-and-compliance.

// Version: 2.1.323
import{t}from"/$bunfs/root/chunk-jw9em5g5.js";import{g,c}from"/$bunfs/root/chunk-dr8ta7k0.js";import{a1,$fe,G4,Oj}from"/$bunfs/root/chunk-579w43z0.js";import{Ebe}from"/$bunfs/root/chunk-vw41nesg.js";async function $7e(){a1(),Oj(),$fe(),G4.emit();try{await Ebe.rehome(),g("skill_directory_reload")}catch(r){t(`directory change: re-targeting the skill watcher failed (continuing with the previous watch): ${r}`,{level:"error"}),c("skill_directory_reload","rehome_failed")}}
export{$7e};
