// @bun @bytecode
// (c) Anthropic PBC. All rights reserved. Use is subject to the Legal Agreements outlined here: https://code.claude.com/docs/en/legal-and-compliance.

// Version: 2.1.323
import{l2}from"/$bunfs/root/chunk-ets06900.js";import{i}from"/$bunfs/root/chunk-3nae1zmb.js";var XDs="no_reply_needed",nan=`__${XDs}`,l=`mcp__${l2}${nan}`,JDs=["__message_coordinator","__message_thread"];function QDs(e){return!JDs.some((s)=>e.endsWith(s))}function cle(){return new Set((i.CLAUDE_CODE_TERMINAL_MCP_TOOLS||"").split(",").map((e)=>e.trim()).filter(Boolean))}function KMr(){return cle().values().some((e)=>e.endsWith(nan)&&e!==l)}function P1t(e){let s=cle();if(s.size===0)return!1;let _=new Set;for(let r=e.length-1;r>=0;r--){let o=e[r];if(o.type==="user"){if(o.isMeta)continue;let t=o.message.content;if(!Array.isArray(t))return!1;let a=!1;for(let n of t)if(n.type==="tool_result"){if(a=!0,!n.is_error)_.add(n.tool_use_id)}if(!a)return!1}else if(o.type==="assistant"){for(let t of o.message.content)if(t.type==="tool_use"&&_.has(t.id)&&s.has(t.name))return!0}}return!1}
export{XDs,nan,JDs,QDs,cle,KMr,P1t};
