// @bun @bytecode
// (c) Anthropic PBC. All rights reserved. Use is subject to the Legal Agreements outlined here: https://code.claude.com/docs/en/legal-and-compliance.

// Version: 2.1.323
import{S}from"/$bunfs/root/chunk-qxb2gr8e.js";function Jor(){try{return S("tengu_violin_corner",!1)===!0}catch{return!1}}
export{Jor};
