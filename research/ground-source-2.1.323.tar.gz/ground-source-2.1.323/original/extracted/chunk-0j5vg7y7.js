// @bun @bytecode
// (c) Anthropic PBC. All rights reserved. Use is subject to the Legal Agreements outlined here: https://code.claude.com/docs/en/legal-and-compliance.

// Version: 2.1.323
import{d,mQn}from"/$bunfs/root/chunk-qb4yqgcv.js";import{t}from"/$bunfs/root/chunk-jw9em5g5.js";function gwe(o){try{let r=o(),e=typeof r==="object"&&r!==null&&"default"in r?r.default:r;if(typeof e!=="string")throw Error("a bundled text did not load as a string");return e}catch(r){let e=r instanceof Error?r.cause:void 0;throw t(`A bundled text could not be read: ${d(r)}; asset: ${mQn(r)}; cause: ${d(e)}`,{level:"error"}),r}}
export{gwe};
