// @bun @bytecode
// (c) Anthropic PBC. All rights reserved. Use is subject to the Legal Agreements outlined here: https://code.claude.com/docs/en/legal-and-compliance.

// Version: 2.1.323
import{v}from"/$bunfs/root/chunk-sy4f915e.js";import{s,n}from"/$bunfs/root/chunk-cypymn6c.js";import{Ce}from"/$bunfs/root/chunk-qpt5w2b8.js";import{e}from"/$bunfs/root/chunk-acvj0j80.js";import{Zt,ve,y,j}from"/$bunfs/root/chunk-n9sxn37x.js";j();function x(){return!1}var t=Zt(!1);function kue(){return ve(t)}function $Ma(r){let{children:o}=r;return Ce(),y(x),o}function FYr(r){let l=v(2),{children:o}=r,c;if(l[0]!==o)c=e(t,{value:!0,children:e(s,{flexDirection:"column",paddingLeft:1,children:o})}),l[0]=o,l[1]=c;else c=l[1];return c}function VWe(r){let{children:o,bold:l,color:c}=r;return kue()?e(n,{children:o}):e(n,{bold:l,color:c,children:o})}
export{kue,$Ma,FYr,VWe};
