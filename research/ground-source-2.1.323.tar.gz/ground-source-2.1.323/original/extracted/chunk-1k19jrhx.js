// @bun @bytecode
// (c) Anthropic PBC. All rights reserved. Use is subject to the Legal Agreements outlined here: https://code.claude.com/docs/en/legal-and-compliance.

// Version: 2.1.323
import{Mp}from"/$bunfs/root/chunk-e9zd9099.js";var a=120000,s=600000;function Cq(n=process.env){let e=n.BASH_DEFAULT_TIMEOUT_MS;if(e){let t=Mp(e);if(!isNaN(t)&&t>0)return t}return a}function ZX(n=process.env){let e=n.BASH_MAX_TIMEOUT_MS;if(e){let t=Mp(e);if(!isNaN(t)&&t>0)return Math.max(t,Cq(n))}return Math.max(s,Cq(n))}var W9i=1800000,lwo=7200000;function G9i(n){return Math.min(Math.max(n,ZX()),2147483647)}function z9i(n,e){return Math.max(n,Cq(e))}function v_t(n,e){return n!==void 0&&n>0?e:void 0}var i=2000;function GRr({requestedTimeoutMs:n,isMainAgent:e,canAutoBackground:t,subagentCapMs:o=0,env:u=process.env}){if(!t)return n;let r=e?Mp(u.CLAUDE_CODE_AUTO_BACKGROUND_TIMEOUT_MS):o;if(isNaN(r)||r<=0)return n;return Math.min(n,Math.max(r,i))}
export{Cq,ZX,W9i,lwo,G9i,z9i,v_t,GRr};
