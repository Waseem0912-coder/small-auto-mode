// @bun @bytecode
// (c) Anthropic PBC. All rights reserved. Use is subject to the Legal Agreements outlined here: https://code.claude.com/docs/en/legal-and-compliance.

// Version: 2.1.323
function Cne(e){return e==="interactive"||e==="sdk"||e==="bg_session"}var _ra={kind:"repliesConsentWriter"};
export{Cne,_ra};
