// @bun @bytecode
// (c) Anthropic PBC. All rights reserved. Use is subject to the Legal Agreements outlined here: https://code.claude.com/docs/en/legal-and-compliance.

// Version: 2.1.323
import{ch,Un}from"/$bunfs/root/chunk-c39a0cpy.js";import{D9,pwt}from"/$bunfs/root/chunk-5wk9qwkf.js";import{eze,XA,Xc,Pb,PP}from"/$bunfs/root/chunk-579w43z0.js";function d(e){return e!==void 0&&ch(e)?{kind:"unresolved",reason:"Its marketplace is a folder whose catalog could not be read, or lists it no more."}:{kind:"copy"}}async function gzo(e,o){let[r,l]=await Promise.all([PP(e,o),Xc(o)]),n=l[Un(e).marketplace??""]?.source;if(r===null)return d(n);let{source:t}=r.entry,c=eze(t,n);if(typeof t!=="string"||!c)return{kind:"copy"};let i=Pb(r.marketplaceInstallLocation)===void 0?"workspace":"system",a=await D9(e,r.marketplaceInstallLocation,t,l,XA(),o,i);return a.kind==="ok"?{kind:"folder",path:a.entryPath}:{kind:"unresolved",reason:pwt(a,r.marketplaceInstallLocation,t).message}}export{gzo};
