// @bun @bytecode
// (c) Anthropic PBC. All rights reserved. Use is subject to the Legal Agreements outlined here: https://code.claude.com/docs/en/legal-and-compliance.

// Version: 2.1.323
function cp(e){return e.name?.startsWith("mcp__")||e.isMcp===!0}function ptt(e){return e.mcpInfo?.serverName??(e.name?.startsWith("mcp__")?e.name.split("__")[1]:void 0)}
export{cp,ptt};
