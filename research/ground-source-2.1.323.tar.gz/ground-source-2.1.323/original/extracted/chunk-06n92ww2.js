// @bun @bytecode
// (c) Anthropic PBC. All rights reserved. Use is subject to the Legal Agreements outlined here: https://code.claude.com/docs/en/legal-and-compliance.

// Version: 2.1.323
var o=["default"];function uPn(t){let e=t.toLowerCase();if(!o.includes(e))return null;return e}
export{uPn};
