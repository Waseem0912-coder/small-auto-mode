// @bun @bytecode
// (c) Anthropic PBC. All rights reserved. Use is subject to the Legal Agreements outlined here: https://code.claude.com/docs/en/legal-and-compliance.

// Version: 2.1.323
import{tt}from"/$bunfs/root/chunk-wzy8gy9y.js";import{_}from"/$bunfs/root/chunk-jw9em5g5.js";import{p}from"/$bunfs/root/chunk-xbvp5g1t.js";import{_u,I,u,B,T}from"/$bunfs/root/chunk-4n4tpjsg.js";var t=1,f=65536,r=p(()=>_u().min(0).default(0)),m=p(()=>u({version:_u()})),n=p(()=>u({version:T(t),generation:_u().min(1),appliedBeforeFirstAsk:I(),outcome:B(["applied","partial"]),filesApplied:r(),filesRefused:r(),settingsWritten:I().default(!1),replacedForeign:r(),writtenAtMs:_u().min(0)}));function Ois(o){let e=n().safeParse({...o,version:t});if(!e.success)throw Error("home ready row is off-schema");return Buffer.from(_(e.data))}function Lpr(o){if(o.length>f)return{ok:!1,reason:"oversize"};let e=tt(o.toString("utf8"),!1),s=m().safeParse(e);if(s.success&&s.data.version!==t)return{ok:!1,reason:"unsupported_version"};let a=n().safeParse(e);if(!a.success)return{ok:!1,reason:"malformed"};let{version:l,...i}=a.data;return{ok:!0,ready:i}}
export{Ois,Lpr};
