// @bun @bytecode
// (c) Anthropic PBC. All rights reserved. Use is subject to the Legal Agreements outlined here: https://code.claude.com/docs/en/legal-and-compliance.

// Version: 2.1.323
import{v}from"/$bunfs/root/chunk-sy4f915e.js";import{s,n}from"/$bunfs/root/chunk-cypymn6c.js";import{e,r}from"/$bunfs/root/chunk-acvj0j80.js";import{se}from"/$bunfs/root/chunk-z0cgbdx4.js";import{k}from"/$bunfs/root/chunk-09hdecqv.js";function m_(d){let i=v(4),{children:o,color:t}=d,l;if(i[0]===k)l=e(s,{"aria-hidden":!0,width:2,flexShrink:0,children:e(n,{children:se.bullet})}),i[0]=l;else l=i[0];let c;if(i[1]!==o||i[2]!==t)c=r(s,{flexDirection:"row",children:[l,e(s,{flexGrow:1,flexShrink:1,children:e(n,{color:t,children:o})})]}),i[1]=o,i[2]=t,i[3]=c;else c=i[3];return c}
export{m_};
