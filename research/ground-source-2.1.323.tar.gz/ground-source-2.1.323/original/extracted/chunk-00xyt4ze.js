// @bun @bytecode
// (c) Anthropic PBC. All rights reserved. Use is subject to the Legal Agreements outlined here: https://code.claude.com/docs/en/legal-and-compliance.

// Version: 2.1.323
import{ni}from"/$bunfs/root/chunk-eedkk1vs.js";import{le}from"/$bunfs/root/chunk-be5qnx1h.js";function Yln(n){return le()&&ni(n)==="turn-abort"}function eVa(n){return le()&&n!==null&&typeof n==="object"&&"asyncDispatched"in n&&n.asyncDispatched===!0}
export{Yln,eVa};
