// @bun @bytecode
// (c) Anthropic PBC. All rights reserved. Use is subject to the Legal Agreements outlined here: https://code.claude.com/docs/en/legal-and-compliance.

// Version: 2.1.323
import{Cw}from"/$bunfs/root/chunk-bjagqp0a.js";var Em=Symbol("untrustedArray.unreadable"),cre="<unreadable list>";function Zv(e){let n;try{if(!Array.isArray(e))return;n=e.length}catch{return Em}if(typeof n!=="number"||!Number.isSafeInteger(n)||n<0||n>Cw)return Em;let u=[];for(let r=0;r<n;r++){let t;try{t=e[r]}catch{t=void 0}u.push(t)}return u}function whe(e){let n=Zv(e);return n===Em?void 0:n}
export{Em,cre,Zv,whe};
