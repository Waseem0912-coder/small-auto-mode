// @bun @bytecode
// (c) Anthropic PBC. All rights reserved. Use is subject to the Legal Agreements outlined here: https://code.claude.com/docs/en/legal-and-compliance.

// Version: 2.1.323
import{St}from"/$bunfs/root/chunk-stjwya8s.js";var a="/$bunfs/root/docs.mjs-0d218ce7.txt.zst";var t=St(a,import.meta.dirname);export{t as default};
