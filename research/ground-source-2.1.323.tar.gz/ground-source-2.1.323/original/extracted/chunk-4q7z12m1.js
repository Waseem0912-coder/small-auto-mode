// @bun @bytecode
// (c) Anthropic PBC. All rights reserved. Use is subject to the Legal Agreements outlined here: https://code.claude.com/docs/en/legal-and-compliance.

// Version: 2.1.323
import{fIe,yOo}from"/$bunfs/root/chunk-wqwj2mm1.js";export{fIe as APPIFACT_REPL_TOOL_NAME,yOo as DESCRIPTION};
