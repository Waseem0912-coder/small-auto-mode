// @bun @bytecode
// (c) Anthropic PBC. All rights reserved. Use is subject to the Legal Agreements outlined here: https://code.claude.com/docs/en/legal-and-compliance.

// Version: 2.1.323
import{JRt,OKo}from"/$bunfs/root/chunk-3gpyadw3.js";import"/$bunfs/root/chunk-498nre94.js";import"/$bunfs/root/chunk-sy4f915e.js";import"/$bunfs/root/chunk-er9ga5ee.js";import"/$bunfs/root/chunk-0qyb3r5p.js";export{JRt as createFleetViewHost,OKo as useAttachFleetOwners};
