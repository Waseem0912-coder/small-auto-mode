// @bun @bytecode
// (c) Anthropic PBC. All rights reserved. Use is subject to the Legal Agreements outlined here: https://code.claude.com/docs/en/legal-and-compliance.

// Version: 2.1.323
import{W}from"/$bunfs/root/chunk-1zs6h7k0.js";class o{restored=!1;markRestored(){this.restored=!0}}var r=new W(()=>new o);function QPt(t){r.of(t).markRestored()}function nG(t){return r.of(t).restored}
export{QPt,nG};
