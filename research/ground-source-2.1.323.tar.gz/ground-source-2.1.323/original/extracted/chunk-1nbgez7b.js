// @bun @bytecode
// (c) Anthropic PBC. All rights reserved. Use is subject to the Legal Agreements outlined here: https://code.claude.com/docs/en/legal-and-compliance.

// Version: 2.1.323
import{i}from"/$bunfs/root/chunk-3nae1zmb.js";import{x}from"/$bunfs/root/chunk-dta9rd6b.js";import{rP,NPa}from"/$bunfs/root/chunk-y2bfr1vh.js";function Zur(){return rP()&&!NPa()&&!i.CLAUDE_CODE_REMOTE_SESSION_ID&&x()!=="wsl"}
export{Zur};
