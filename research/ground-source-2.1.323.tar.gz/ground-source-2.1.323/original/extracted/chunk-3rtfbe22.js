// @bun @bytecode
// (c) Anthropic PBC. All rights reserved. Use is subject to the Legal Agreements outlined here: https://code.claude.com/docs/en/legal-and-compliance.

// Version: 2.1.323
import{e9,QRs,ZRs}from"/$bunfs/root/chunk-kvxc122t.js";import"/$bunfs/root/chunk-8gwmbypr.js";export{QRs as DESCRIPTION,ZRs as PROMPT,e9 as SEARCH_MCP_REGISTRY_TOOL_NAME};
