// @bun @bytecode
// (c) Anthropic PBC. All rights reserved. Use is subject to the Legal Agreements outlined here: https://code.claude.com/docs/en/legal-and-compliance.

// Version: 2.1.323
import{ib}from"/$bunfs/root/chunk-qxb2gr8e.js";import{AD,CX,Vpo,OX,zM}from"/$bunfs/root/chunk-579w43z0.js";import{oe}from"/$bunfs/root/chunk-casmt0wz.js";async function LCn({toolUseContext:e,forkContextMessages:o,mainThreadAgentDefinition:t}){let{systemPrompt:s,userContext:m,systemContext:r}=Vpo()??await i(e,t);return{systemPrompt:s,userContext:m,systemContext:r,toolUseContext:e,forkContextMessages:o,advisorModel:e.getAdvisorSetting()}}async function i(e,o){let[t,s,m]=await Promise.all([e.renderedSystemPrompt??n(e,o),zM(e.session,e.storageV5,e.credentials),OX(e.session,e.options.cacheBreakerPhrase)]);return{systemPrompt:t,userContext:s,systemContext:m}}async function n(e,o){let t=oe(e),s=await AD(e.options.tools,ib({permissionMode:t.mode,mainLoopModel:e.options.mainLoopModel}));return CX({mainThreadAgentDefinition:o,toolUseContext:e,customSystemPrompt:e.options.customSystemPrompt,defaultSystemPrompt:s,appendSystemPrompt:e.options.appendSystemPrompt})}
export{LCn};
