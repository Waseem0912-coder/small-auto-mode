// @bun @bytecode
// (c) Anthropic PBC. All rights reserved. Use is subject to the Legal Agreements outlined here: https://code.claude.com/docs/en/legal-and-compliance.

// Version: 2.1.323
import{d}from"/$bunfs/root/chunk-qb4yqgcv.js";import{ps}from"/$bunfs/root/chunk-0qyb3r5p.js";import{t,_}from"/$bunfs/root/chunk-jw9em5g5.js";import{qn}from"/$bunfs/root/chunk-ggqpfrwt.js";import{fie}from"/$bunfs/root/chunk-ktj73fj8.js";import{Xfa}from"/$bunfs/root/chunk-0jj8mad6.js";import{unlinkSync as s}from"fs";import{mkdir as c}from"fs/promises";import{join as i}from"path";function gus(){return i(Xfa(),"claude","locks")}function bXe(){return!ps(void 0)}async function i_r(){let r=fie(process.execPath);if(r===void 0||!bXe())return;try{let o=gus(),e=i(o,`${r}@${process.pid}.lock`),n={pid:process.pid,version:r,execPath:process.execPath,acquiredAt:Date.now()};await c(o,{recursive:!0}),await qn(e,_(n,null,2)),process.on("exit",()=>{try{s(e)}catch{}})}catch(o){t(`Could not write this process's version lock, so a later update may delete the app bundle it runs from: ${d(o)}`,{level:"warn"})}}
export{gus,bXe,i_r};
