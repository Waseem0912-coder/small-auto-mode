// @bun @bytecode
// (c) Anthropic PBC. All rights reserved. Use is subject to the Legal Agreements outlined here: https://code.claude.com/docs/en/legal-and-compliance.

// Version: 2.1.323
import{hn}from"/$bunfs/root/chunk-js6ax81v.js";import{Re}from"/$bunfs/root/chunk-a6b2ht67.js";import{ySt,eB}from"/$bunfs/root/chunk-dbjt8m89.js";function Xwn(i){if(i.toolName===Re){if(!i.ruleContent)return{prefix:"Any Bash command"};if(i.ruleContent.endsWith(":*")||i.ruleContent.endsWith(" *"))return{prefix:"Any Bash command starting with ",emphasis:i.ruleContent.slice(0,-2)};return{prefix:"The Bash command ",emphasis:i.ruleContent}}if(eB(i))return{prefix:`This rule ${ySt(hn(i),i.toolName)}`};if(!i.ruleContent)return{prefix:"Any use of the ",emphasis:i.toolName,suffix:" tool"};return null}
export{Xwn};
