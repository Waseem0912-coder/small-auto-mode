// @bun @bytecode
// (c) Anthropic PBC. All rights reserved. Use is subject to the Legal Agreements outlined here: https://code.claude.com/docs/en/legal-and-compliance.

// Version: 2.1.323
import{i}from"/$bunfs/root/chunk-3nae1zmb.js";import{Pr}from"/$bunfs/root/chunk-59sqgzfc.js";import{Gdn}from"/$bunfs/root/chunk-c79wrf1z.js";function LPi({isNonInteractiveSession:e=!1,settings:n=Pr()??{}}={}){return Gdn({cli:{isNonInteractiveSession:e},env:{CLAUDE_CODE_REMOTE:i.CLAUDE_CODE_REMOTE?"1":void 0,CLAUDE_CODE_BRIDGE_CHILD_AUTO_DEFAULT:i.CLAUDE_CODE_BRIDGE_CHILD_AUTO_DEFAULT?"1":void 0,USER_TYPE:"external"},settings:n})}
export{LPi};
