// @bun @bytecode
// (c) Anthropic PBC. All rights reserved. Use is subject to the Legal Agreements outlined here: https://code.claude.com/docs/en/legal-and-compliance.

// Version: 2.1.323
import{Gt,Zp}from"/$bunfs/root/chunk-0gs9z29h.js";import{iBt}from"/$bunfs/root/chunk-1x32sd96.js";import{rh}from"/$bunfs/root/chunk-fcm9dqd4.js";import{Oo}from"/$bunfs/root/chunk-dp5ybvjq.js";function wRi(){return rh()?Zp:Gt}function trs(){return rh()?`the ${Zp} tool (load it with ${Oo}, query \`select:${Zp}\`, if it is not loaded)`:`the ${Gt} tool`}function U7(t){return`${Zp} tool, action "${t==="comments"?"read":t}"`}function gc(t,o){return rh()?o():t}function vRi(t,o){return rh()?{name:Zp,input:iBt("comments",o)}:{name:t,input:o}}
export{wRi,trs,U7,gc,vRi};
