// @bun @bytecode
// (c) Anthropic PBC. All rights reserved. Use is subject to the Legal Agreements outlined here: https://code.claude.com/docs/en/legal-and-compliance.

// Version: 2.1.323
import{K}from"/$bunfs/root/chunk-s67bjq59.js";import{ss}from"/$bunfs/root/chunk-f7tfz0rn.js";import{Bp}from"/$bunfs/root/chunk-2rhdc6tt.js";import{Din}from"/$bunfs/root/chunk-kkcts7re.js";import{sep as i}from"path";function cNt(t){if(K())return null;let e=`${Din()}${i}`,n=".output";if(t.startsWith(e)&&t.endsWith(n)){let r=t.slice(e.length,-n.length);if(r.length>0&&r.length<=20&&/^[a-zA-Z0-9_-]+$/.test(r))return r}return null}function UVi(t){if(t?.file_path?.startsWith(Bp()))return"Reading Plan";if(t?.file_path&&cNt(t.file_path))return"Read agent output";return"Read"}function Qws(t){if(!t?.file_path)return null;let e=cNt(t.file_path);if(e)return e;return ss(t.file_path)}
export{cNt,UVi,Qws};
