// @bun @bytecode
// (c) Anthropic PBC. All rights reserved. Use is subject to the Legal Agreements outlined here: https://code.claude.com/docs/en/legal-and-compliance.

// Version: 2.1.323
import{Le}from"/$bunfs/root/chunk-0qyb3r5p.js";import{F}from"/$bunfs/root/chunk-s67bjq59.js";import{W}from"/$bunfs/root/chunk-1zs6h7k0.js";class n{inFlightSnapshot={tasks:0,queued:0,kinds:[],items:[]};inFlightSnapshotChanged=Le();pendingStructuredResult=void 0;jobRecordSeenIn=void 0;relocatedCwd=void 0;ownStateWriteDepth=0;warnedUnknownDisabledSurface=!1;publishInFlightSnapshot(e){this.inFlightSnapshot=e;try{this.inFlightSnapshotChanged.emit()}catch{}}reset(){this.pendingStructuredResult=void 0,this.jobRecordSeenIn=void 0,this.relocatedCwd=void 0,this.warnedUnknownDisabledSurface=!1,this.publishInFlightSnapshot({tasks:0,queued:0,kinds:[],items:[]})}}var t=new W(()=>new n);function V8(){return t.of(F().host)}
export{V8};
