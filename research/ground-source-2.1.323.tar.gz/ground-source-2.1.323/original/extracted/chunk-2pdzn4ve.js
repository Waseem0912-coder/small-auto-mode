// @bun @bytecode
// (c) Anthropic PBC. All rights reserved. Use is subject to the Legal Agreements outlined here: https://code.claude.com/docs/en/legal-and-compliance.

// Version: 2.1.323
import{rk}from"/$bunfs/root/chunk-qxb2gr8e.js";import{WO}from"/$bunfs/root/chunk-wq6gfs6b.js";import{Fct}from"/$bunfs/root/chunk-fswc2gh6.js";var n="tengu_violin_fret";async function iMa(){try{return await rk(n)}catch{return!1}}async function OVo(){return Fct()&&await WO()&&await iMa()}
export{iMa,OVo};
