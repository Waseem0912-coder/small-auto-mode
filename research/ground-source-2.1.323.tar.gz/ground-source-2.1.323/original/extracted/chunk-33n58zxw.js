// @bun @bytecode
// (c) Anthropic PBC. All rights reserved. Use is subject to the Legal Agreements outlined here: https://code.claude.com/docs/en/legal-and-compliance.

// Version: 2.1.323
import{b}from"/$bunfs/root/chunk-er9ga5ee.js";import{t}from"/$bunfs/root/chunk-jw9em5g5.js";import{l}from"/$bunfs/root/chunk-1zd9p1tg.js";import{On}from"/$bunfs/root/chunk-cypymn6c.js";import{Ect}from"/$bunfs/root/chunk-wnsa1b37.js";import{ce,y,j}from"/$bunfs/root/chunk-n9sxn37x.js";j();function u(o,n,r){return o.isWindowActivation||i(n,r)}function pE(){let o=On(),[n]=y(()=>o.now());return ce((r)=>{let e=o.now();if(!u(r,n,e))return!1;let c=r.isWindowActivation?b("window_activation"):b("mount_settle");return t(`Select: dropped stray click (${r.isWindowActivation?"window-activation click":`${e-n}ms after mount`})`),l("tengu_select_stray_click_dropped",{reason:c}),r.dropAsStray(),!0},[o,n])}function $5t(){let o=On(),[n]=y(()=>o.now());return ce(()=>i(n,o.now()),[o,n])}function i(o,n){return n-o<Ect}
export{pE,$5t};
