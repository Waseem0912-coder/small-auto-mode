// @bun @bytecode
// (c) Anthropic PBC. All rights reserved. Use is subject to the Legal Agreements outlined here: https://code.claude.com/docs/en/legal-and-compliance.

// Version: 2.1.323
import{v}from"/$bunfs/root/chunk-sy4f915e.js";import{s,n}from"/$bunfs/root/chunk-cypymn6c.js";import{Z0e,Tt}from"/$bunfs/root/chunk-ychhzwcr.js";import{e,r}from"/$bunfs/root/chunk-acvj0j80.js";function Eu(x){let i=v(9),{status:t,children:l}=x,{color:o}=Z0e[t],c;if(i[0]!==t)c=e(s,{width:2,flexShrink:0,children:e(Tt,{status:t})}),i[0]=t,i[1]=c;else c=i[1];const u=!o;let a;if(i[2]!==l||i[3]!==o||i[4]!==u)a=e(s,{flexGrow:1,flexShrink:1,children:e(n,{color:o,dimColor:u,children:l})}),i[2]=l,i[3]=o,i[4]=u,i[5]=a;else a=i[5];let d;if(i[6]!==c||i[7]!==a)d=r(s,{flexDirection:"row",children:[c,a]}),i[6]=c,i[7]=a,i[8]=d;else d=i[8];return d}
export{Eu};
