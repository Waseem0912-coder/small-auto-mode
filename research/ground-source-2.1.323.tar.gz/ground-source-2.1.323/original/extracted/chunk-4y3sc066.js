// @bun @bytecode
// (c) Anthropic PBC. All rights reserved. Use is subject to the Legal Agreements outlined here: https://code.claude.com/docs/en/legal-and-compliance.

// Version: 2.1.323
import"/$bunfs/root/chunk-2cpk709w.js";import"/$bunfs/root/chunk-vqc7veg7.js";import{$Gs,UGs}from"/$bunfs/root/chunk-dps5gkxc.js";import"/$bunfs/root/chunk-s9sdkh90.js";import"/$bunfs/root/chunk-qnya2kzh.js";import"/$bunfs/root/chunk-vdq67jcz.js";import"/$bunfs/root/chunk-1r87t7tn.js";import"/$bunfs/root/chunk-fyz074nv.js";import"/$bunfs/root/chunk-9bcg10ax.js";import"/$bunfs/root/chunk-5mjf6j01.js";export{UGs as GetRoleCredentialsCommand,$Gs as SSOClient};
