// @bun @bytecode
// (c) Anthropic PBC. All rights reserved. Use is subject to the Legal Agreements outlined here: https://code.claude.com/docs/en/legal-and-compliance.

// Version: 2.1.323
var Jme="artifact-design",Laa="artifact-diagramming",yR="artifact-capabilities",Haa="whiteboard",sHr="dataviz",Rle="design",iHr="design-sync",aHr="slides",zJ="code-review",rve="verify",xGn="simplify",PGn="commit",IGn="pr",kUs="commit-push-pr",lHr="cowork-plugin",Naa="explain-usage",Faa="setup-claude",dHr="security-review";var gUe="loop",mjt="schedule",nB="workflow-authoring";
export{Jme,Laa,yR,Haa,sHr,Rle,iHr,aHr,zJ,rve,xGn,PGn,IGn,kUs,lHr,Naa,Faa,dHr,gUe,mjt,nB};
