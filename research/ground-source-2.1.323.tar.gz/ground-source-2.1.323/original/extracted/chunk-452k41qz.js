// @bun @bytecode
// (c) Anthropic PBC. All rights reserved. Use is subject to the Legal Agreements outlined here: https://code.claude.com/docs/en/legal-and-compliance.

// Version: 2.1.323
import{F}from"/$bunfs/root/chunk-s67bjq59.js";import{M,y,j}from"/$bunfs/root/chunk-n9sxn37x.js";import{qe}from"/$bunfs/root/chunk-mzwcxmkk.js";j();var oGe="continue";function RPi(t,e,n){if(n&&e===oGe&&t===oGe+"/")return"/";if(e.startsWith("/")&&t.length===oGe.length+e.length+1&&t.startsWith(oGe+e))return t.slice(oGe.length);return t}class o{lastResult=null;listeners=new Set;inFlight=null}var l=new qe(()=>new o);function i(){return l.of(F())}function Wro(t){let e=i();e.lastResult=t;for(let n of e.listeners)n(t)}function xPi(){return i().inFlight}function Zos(t){i().inFlight=t}function PPi(){Wro(null),i().inFlight=null}function IPi(){let[t,e]=y(()=>i().lastResult);return M(()=>{let n=i();return e(n.lastResult),n.listeners.add(e),()=>{n.listeners.delete(e)}},[]),t}
export{oGe,RPi,Wro,xPi,Zos,PPi,IPi};
