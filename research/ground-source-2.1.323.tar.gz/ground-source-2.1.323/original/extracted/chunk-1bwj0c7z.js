// @bun @bytecode
// (c) Anthropic PBC. All rights reserved. Use is subject to the Legal Agreements outlined here: https://code.claude.com/docs/en/legal-and-compliance.

// Version: 2.1.323
function lr(e){return e?.type==="system"&&e.subtype==="compact_boundary"}function tIr(e){if(e.type==="user")return e.replacesSpan===!0;return!1}function rme(e){for(let t=e.length-1;t>=0;t--){let s=e[t];if(s&&lr(s))return t}return-1}var nIr="Loaded from the session's last compaction, so the messages it summarized aren't here.";function rIr(e){let t=rme(e),s=e[t];if(!s||!lr(s))return!1;let r=s.compactMetadata?.preservedMessages?.uuids,o=new Set(Array.isArray(r)?r:[]);return e.slice(0,t).every((n)=>o.has(n.uuid))}function as(e,t){let s=rme(e);return s===-1?e:e.slice(s)}
export{lr,tIr,rme,nIr,rIr,as};
