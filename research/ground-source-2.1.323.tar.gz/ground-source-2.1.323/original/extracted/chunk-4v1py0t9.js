// @bun @bytecode
// (c) Anthropic PBC. All rights reserved. Use is subject to the Legal Agreements outlined here: https://code.claude.com/docs/en/legal-and-compliance.

// Version: 2.1.323
import{O}from"/$bunfs/root/chunk-13w6644x.js";import{$ue}from"/$bunfs/root/chunk-hsz65t2c.js";import{Et}from"/$bunfs/root/chunk-5d6r8r6y.js";import{Jt}from"/$bunfs/root/chunk-x18chhf8.js";var CEi=(t)=>`${t.path} (${Jt(t.bytes)})`;var yZo=(t,r)=>[t].filter((e)=>e>0).map((e)=>`and ${e} more ${O(e,r)} not named here`);var ZZr=(t)=>(/^ */.exec(t)?.[0]??"")+Et(t,$ue);var bZo=(t)=>[t].filter((r)=>r>0).map((r)=>`${r} ${O(r,"entry stays","entries stay")} on this machine (secrets, links, ignored files)`);var SZo=(t)=>[t??[]].flat().flatMap((r)=>[`Writes this manifest first, to ${r.path}:`,...r.text.trimEnd().split(`
`)]);var a=(t)=>`stays here: ${t.path} (${t.words})`;var wZo=(t)=>[...t.files.map(CEi),...yZo(t.unnamed?.files??0,"file"),...t.stays.map(a),...yZo(t.unnamed?.stays??0,"entry")].map(ZZr);export{CEi,yZo,ZZr,bZo,SZo,wZo};
