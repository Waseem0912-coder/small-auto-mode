// @bun @bytecode
// (c) Anthropic PBC. All rights reserved. Use is subject to the Legal Agreements outlined here: https://code.claude.com/docs/en/legal-and-compliance.

// Version: 2.1.323
import{tn}from"/$bunfs/root/chunk-qxb2gr8e.js";import{xne}from"/$bunfs/root/chunk-2rhdc6tt.js";var n="tengu_harp_forepillar";function ZSn(){return tn(n,!1)===!0}function tci(e,t){if(e===t)return"launch_dir";return xne(e,t)?"inside_launch_dir":"elsewhere"}
export{ZSn,tci};
