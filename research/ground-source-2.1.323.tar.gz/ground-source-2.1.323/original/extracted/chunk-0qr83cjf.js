// @bun @bytecode
// (c) Anthropic PBC. All rights reserved. Use is subject to the Legal Agreements outlined here: https://code.claude.com/docs/en/legal-and-compliance.

// Version: 2.1.323
import{i}from"/$bunfs/root/chunk-3nae1zmb.js";function DW(){return i.CLAUDE_CODE_REMOTE&&i.CLAUDE_CODE_REMOTE_HERMETIC_MODE}
export{DW};
