// @bun @bytecode
// (c) Anthropic PBC. All rights reserved. Use is subject to the Legal Agreements outlined here: https://code.claude.com/docs/en/legal-and-compliance.

// Version: 2.1.323
var wxe="SearchPlugins",f1n="SearchSkills",AFe="SuggestPluginInstall",B$t="SuggestSkills",p1n="ListPlugins",rsn="ListSkills",fPr=["SearchPlugins","SearchSkills","ListPlugins","ListSkills"];
export{wxe,f1n,AFe,B$t,p1n,rsn,fPr};
