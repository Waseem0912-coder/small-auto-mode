// @bun @bytecode
// (c) Anthropic PBC. All rights reserved. Use is subject to the Legal Agreements outlined here: https://code.claude.com/docs/en/legal-and-compliance.

// Version: 2.1.323
import{xt}from"/$bunfs/root/chunk-13w6644x.js";import{g3e}from"/$bunfs/root/chunk-ft147hxb.js";import{VYe,$V}from"/$bunfs/root/chunk-1fr5g5zz.js";import{oc,iUr,wN}from"/$bunfs/root/chunk-yb77stkg.js";import{lt}from"/$bunfs/root/chunk-s86z7y3e.js";var A="tengu_temporal_nautilus",k=/[\v\f\r\x1c-\x1e\u0085\u2028\u2029](?=[^\n])/g,d=20,B=65536,E=/[\p{Zs}\u2800]/gu;function f(){return{furtherBreaks:d,inlineMarkChars:B,marksRanOut:!1}}function Nue(){return lt(A,{safe:!0})}function p(r){let t=r.charCodeAt(0);return(t>=128||t===91)&&iUr(oc(r)).replace(E," ").startsWith($V)?r.replace("[","\uFFFD"):r}function w(r,t){let n=p(r);if(n.search(k)===-1)return[n];let e="",s=0,i=0,o=VYe;for(let{index:a}of n.matchAll(k)){let R=n.slice(s,a+1),c=h(R),u=i===0||t.furtherBreaks>0;if(i>0&&(a>=g3e||!u&&t.inlineMarkChars<=0)){t.marksRanOut=!0;break}if(c>o&&o<VYe)e=m(e),o=VYe;if(u&&i>0)t.furtherBreaks--;if(!u)t.inlineMarkChars-=$V.length;let g=u||c+$V.length>o;e+=`${R}${g?`
`:""}${$V}`,o=g?VYe:o-c-$V.length,i++,s=a+1}let l=n.slice(s);if(h(l)>o&&o<VYe)e=m(e);return`${e}${l}`.split(`
`)}function h(r){return r.length+7*xt(r,"\t")}function m(r){return`${r.slice(0,-$V.length)}
${$V}`}function _(r,t){return r.split(`
`).flatMap((n)=>w(n,t)).join(`
`)}function Fue(r){return Nue()?_(r,f()):r}function C2e(r){if(!Nue())return wN(r);let t=f(),n=_(r,t);return t.marksRanOut||wN(r)||n!==r&&wN(n)}function BIt(r){if(!Nue())return r;let t=f(),n=r.lines.flatMap((e)=>e.startsWith("+")?w(e.slice(1),t).map((s)=>`+${s}`):[`${e.charAt(0)}${p(e.slice(1))}`]);return{...r,lines:n,rowsBroken:!0}}
export{Nue,Fue,C2e,BIt};
