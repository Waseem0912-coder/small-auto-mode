// @bun @bytecode
// (c) Anthropic PBC. All rights reserved. Use is subject to the Legal Agreements outlined here: https://code.claude.com/docs/en/legal-and-compliance.

// Version: 2.1.323
import{hl}from"/$bunfs/root/chunk-rbf0x6dj.js";import{t}from"/$bunfs/root/chunk-jw9em5g5.js";import{pr,rAt}from"/$bunfs/root/chunk-k0ktnhv0.js";var r=/^[a-zA-Z0-9_-]{1,64}$/;function wor(i,n=hl){if(!("tools"in i)||i.tools===void 0)return[];if(!Array.isArray(i.tools))return t("[bridge:meta-mcp] meta tools[] is not an array",{level:"warn"}),null;let e=[];for(let o of i.tools){if(o===null||typeof o!=="object"||!("name"in o)||typeof o.name!=="string"||!r.test(o.name))return t("[bridge:meta-mcp] injected tools[] entry is malformed",{level:"warn"}),null;e.push({name:o.name,..."permission_policy"in o&&typeof o.permission_policy==="string"&&{permission_policy:o.permission_policy}})}let{allow:s}=rAt({[n]:{type:"http",tools:e}}),l=pr(n,"");return s.map((o)=>o.startsWith(l)?o.slice(l.length):o)}
export{wor};
