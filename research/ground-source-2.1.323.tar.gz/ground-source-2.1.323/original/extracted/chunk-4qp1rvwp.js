// @bun @bytecode
// (c) Anthropic PBC. All rights reserved. Use is subject to the Legal Agreements outlined here: https://code.claude.com/docs/en/legal-and-compliance.

// Version: 2.1.323
import{ke}from"/$bunfs/root/chunk-chrnz2s4.js";import{Ijr,Ja,zn}from"/$bunfs/root/chunk-qxb2gr8e.js";var r=86400000,n=3*r;function onr(){if(ke()!=="firstParty"||!Ja())return null;let e=zn();if(!e?.refreshToken||!Ijr(e.refreshTokenExpiresAt))return null;let t=e.refreshTokenExpiresAt;if(typeof e.expiresAt==="number"&&e.expiresAt>t+n)return null;return new Date(t)}function M3t(){let e=onr();if(e===null)return null;let t=e.getTime()-Date.now();if(t>n||t<=0)return null;return{daysLeft:Math.ceil(t/r)}}
export{onr,M3t};
