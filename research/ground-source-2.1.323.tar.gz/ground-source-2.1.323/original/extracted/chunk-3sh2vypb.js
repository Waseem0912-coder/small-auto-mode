// @bun @bytecode
// (c) Anthropic PBC. All rights reserved. Use is subject to the Legal Agreements outlined here: https://code.claude.com/docs/en/legal-and-compliance.

// Version: 2.1.323
import{To}from"/$bunfs/root/chunk-k7ecs2xs.js";var VDo=To();var BIe=()=>VDo.get();export{VDo,BIe};
