// @bun @bytecode
// (c) Anthropic PBC. All rights reserved. Use is subject to the Legal Agreements outlined here: https://code.claude.com/docs/en/legal-and-compliance.

// Version: 2.1.323
import{Yt}from"/$bunfs/root/chunk-210pgrfb.js";import{ye}from"/$bunfs/root/chunk-59sqgzfc.js";import{Xg,ZVn,aQ}from"/$bunfs/root/chunk-434kjt2g.js";function i(){return c(aQ(ZVn(),"globalConfig"),Yt("userSettings")?aQ(ye("userSettings")?.env,"userSettings"):{},aQ(ye("flagSettings")?.env,"flagSettings"),aQ(ye("policySettings")?.env,"policySettings"))}function AJ(){return g(Xg(),i())}function g(s,n){let r=new Set(Object.keys(n).map((e)=>e.toUpperCase())),t={...s};for(let e of Object.keys(t))if(!(e in n)&&r.has(e.toUpperCase()))delete t[e];return Object.assign(t,n)}function c(...s){let n=new Map;for(let t of s)for(let[e,o]of Object.entries(t))n.set(e.toUpperCase(),{key:e,value:o});let r={};for(let{key:t,value:e}of n.values())r[t]=e;return r}
export{AJ};
