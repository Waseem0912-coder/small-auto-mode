// @bun @bytecode
// (c) Anthropic PBC. All rights reserved. Use is subject to the Legal Agreements outlined here: https://code.claude.com/docs/en/legal-and-compliance.

// Version: 2.1.323
import{S}from"/$bunfs/root/chunk-qxb2gr8e.js";import{KFi,YFi}from"/$bunfs/root/chunk-579w43z0.js";function npt(){if(YFi())return;let e=!1,i;KFi(()=>{if(!e)e=!0,i=S("tengu_mcp_discovery_cache_enable",null)??void 0;return i})}
export{npt};
