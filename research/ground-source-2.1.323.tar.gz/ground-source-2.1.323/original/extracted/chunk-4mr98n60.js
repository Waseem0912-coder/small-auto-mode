// @bun @bytecode
// (c) Anthropic PBC. All rights reserved. Use is subject to the Legal Agreements outlined here: https://code.claude.com/docs/en/legal-and-compliance.

// Version: 2.1.323
import{Hu}from"/$bunfs/root/chunk-qb4yqgcv.js";import{kre,d6e}from"/$bunfs/root/chunk-zcx62ycy.js";var tKn=(r,e)=>kre(r,(o)=>o instanceof Hu)===!0||d6e(r,e);var UUr=(r,e)=>r.catch((o)=>d6e(o,e)?void 0:Promise.reject(o));export{tKn,UUr};
