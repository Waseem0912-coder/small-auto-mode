// @bun @bytecode
// (c) Anthropic PBC. All rights reserved. Use is subject to the Legal Agreements outlined here: https://code.claude.com/docs/en/legal-and-compliance.

// Version: 2.1.323
import{Ao,oM}from"/$bunfs/root/chunk-mh1dhafb.js";import{mf}from"/$bunfs/root/chunk-y2bfr1vh.js";import{Wn}from"/$bunfs/root/chunk-chrnz2s4.js";import{yGe}from"/$bunfs/root/chunk-qajrjy77.js";import{fPr}from"/$bunfs/root/chunk-4dssm8fq.js";class r{reader=void 0;register(e){this.reader=e}read(){return this.reader?.()??!1}}var o=new r;function gas(e){o.register(e)}function $ft(){let e=oM("allow_plugin_skill_search");if(e==="org_denied"||e==="latched"||e==="unregistered"||e!==null&&Ao("hipaa"))return!1;if(yGe())return!0;return mf()&&Wn()&&o.read()}function f2a(e){if(!fPr.includes(e))return!0;return $ft()}
export{gas,$ft,f2a};
