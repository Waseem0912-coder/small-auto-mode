// @bun @bytecode
// (c) Anthropic PBC. All rights reserved. Use is subject to the Legal Agreements outlined here: https://code.claude.com/docs/en/legal-and-compliance.

// Version: 2.1.323
import{Z}from"/$bunfs/root/chunk-13w6644x.js";var VYe=2000,$V="[line break] ";function Eut(r,t=0){let e=VYe+(r.startsWith($V,t)?$V.length:0);if(r.length-t<=e)return{code:r.slice(t),truncatedChars:0};let o=r.slice(t,t+e+1),n=Z(o,e);return{code:n,truncatedChars:r.length-t-n.length}}function qYe(r){return` \u2026 [+${r} chars]`}
export{VYe,$V,Eut,qYe};
