// @bun @bytecode
// (c) Anthropic PBC. All rights reserved. Use is subject to the Legal Agreements outlined here: https://code.claude.com/docs/en/legal-and-compliance.

// Version: 2.1.323
import{cn}from"/$bunfs/root/chunk-8crp4cqc.js";import{QL,wM,fk,Ev}from"/$bunfs/root/chunk-2arat2vg.js";import{Je}from"/$bunfs/root/chunk-v4ex66r9.js";import{tg,VCo}from"/$bunfs/root/chunk-mq8fm74h.js";import{pO}from"/$bunfs/root/chunk-dbh1dwp3.js";import{dirname as v,join as a}from"path";import{realpath as f}from"fs";import{promisify as m}from"util";var h=m(f.native);function c(e){return/^[A-Za-z0-9_-]{1,128}$/.test(e)?e:QL(e)||"empty-id"}async function d(e,t,{isRootResolved:n=!1}={}){return n?cn(e):Ev(e,pO(t))}async function YTi(e,t,n,i){return a(fk(await d(e,n,i)),Veo(t))}async function XTi(e,t,n,i){let o=await d(e,n,i),p=a(fk(o),Veo(t)),r=wM(o),s=n===void 0?void 0:_es(r,t);return{path:p,projectKey:r,v5:n===void 0||s===void 0?void 0:{backend:n,key:s}}}function _es(e,t){let n=Je.dirSyncRecord(e,c(t));return tg(n)===void 0?n:void 0}function Veo(e){return`${c(e)}${VCo}`}
export{YTi,XTi,_es,Veo};
