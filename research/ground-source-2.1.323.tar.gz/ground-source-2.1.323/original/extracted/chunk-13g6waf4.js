// @bun @bytecode
// (c) Anthropic PBC. All rights reserved. Use is subject to the Legal Agreements outlined here: https://code.claude.com/docs/en/legal-and-compliance.

// Version: 2.1.323
import{P}from"/$bunfs/root/chunk-gjcvffe0.js";function Pi(n){return P(n)}
export{Pi};
