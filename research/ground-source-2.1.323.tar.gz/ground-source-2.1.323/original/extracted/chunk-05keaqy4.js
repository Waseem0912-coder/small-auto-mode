// @bun @bytecode
// (c) Anthropic PBC. All rights reserved. Use is subject to the Legal Agreements outlined here: https://code.claude.com/docs/en/legal-and-compliance.

// Version: 2.1.323
import{Of}from"/$bunfs/root/chunk-1jjhhzp7.js";import{we}from"/$bunfs/root/chunk-qxb2gr8e.js";var rqe=(o)=>we().loadedModules.find((e)=>e.name===o&&Of(e));var wE=(o)=>rqe(o)?.args;export{rqe,wE};
