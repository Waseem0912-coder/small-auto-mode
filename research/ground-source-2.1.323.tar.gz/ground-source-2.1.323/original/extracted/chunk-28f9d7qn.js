// @bun @bytecode
// (c) Anthropic PBC. All rights reserved. Use is subject to the Legal Agreements outlined here: https://code.claude.com/docs/en/legal-and-compliance.

// Version: 2.1.323
import{Zyt}from"/$bunfs/root/chunk-xpba9zr8.js";import{XFt}from"/$bunfs/root/chunk-w23w7y57.js";function Jrs(n){return`To fix: ${n.webSetupHint?`${n.webSetupHint}, or connect`:"connect"} an account at ${XFt()} \u2014 ${n.rerun} (allow a minute after connecting).`}function Kur(n){return`${n.subject} with the GitHub account connected to your Claude account, and none is connected (or the connection expired). ${Jrs(n)}`}function Yur(n){let t=n.apostrophe??"'",o=`install the app at ${Zyt}`,e=n.webSetupHint,r=e&&n.leadWithWebSetup?`${e}, or ${o}`:`${o}${e?`, or ${e}`:""}`;return`Your connected GitHub account can${t}t see ${n.owner}/${n.name} \u2014 usually the Claude GitHub app isn${t}t installed on ${n.owner} or wasn${t}t granted this repo (web-connected accounts need it for private repos), or a different GitHub account is connected. To fix: ${r} \u2014 ${n.rerun}.`}
export{Jrs,Kur,Yur};
