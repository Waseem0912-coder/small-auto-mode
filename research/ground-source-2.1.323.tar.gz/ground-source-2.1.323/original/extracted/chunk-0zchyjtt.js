// @bun @bytecode
// (c) Anthropic PBC. All rights reserved. Use is subject to the Legal Agreements outlined here: https://code.claude.com/docs/en/legal-and-compliance.

// Version: 2.1.323
var n=null,r=null,t=null;function Qfa(e,o){n=e,r=o}function Zfa(e){return n?.(e)??null}function dun(e){return r?.(e)??null}function epa(e){t=e}function rqn(){t?.()}
export{Qfa,Zfa,dun,epa,rqn};
