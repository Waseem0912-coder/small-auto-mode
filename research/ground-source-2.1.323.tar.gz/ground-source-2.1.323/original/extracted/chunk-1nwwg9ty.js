// @bun @bytecode
// (c) Anthropic PBC. All rights reserved. Use is subject to the Legal Agreements outlined here: https://code.claude.com/docs/en/legal-and-compliance.

// Version: 2.1.323
import{zf,vTe}from"/$bunfs/root/chunk-qb4yqgcv.js";import{Am}from"/$bunfs/root/chunk-qxb2gr8e.js";import{xL}from"/$bunfs/root/chunk-ft147hxb.js";function PW(r,o){let e=vTe(Am(r)?.code)??zf(r);return{transport:xL(r),...e!==void 0&&{err_code:e},elapsed_ms:Math.round(performance.now()-o)}}
export{PW};
