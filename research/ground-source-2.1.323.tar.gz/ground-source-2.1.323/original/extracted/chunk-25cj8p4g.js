// @bun @bytecode
// (c) Anthropic PBC. All rights reserved. Use is subject to the Legal Agreements outlined here: https://code.claude.com/docs/en/legal-and-compliance.

// Version: 2.1.323
import{p}from"/$bunfs/root/chunk-xbvp5g1t.js";import{zo}from"/$bunfs/root/chunk-g6psjj70.js";import{o,I,ag,u}from"/$bunfs/root/chunk-4n4tpjsg.js";var Fg=zo({kind:"local_jsx",payload:p(()=>u({nodeId:o(),commandName:o(),immediate:I(),hidesPrompt:I(),holdsQueue:I().optional()})),result:p(()=>ag()),default:null,userInvoked:!0,hideWhile:[]}),t=p(()=>u({holdsQueue:I().optional()}));function W7t(a){return a.open.some((e)=>e.kind===Fg.kind&&t().safeParse(e.payload).data?.holdsQueue!==!1)}var sis=new Set(["rate-limit-options","pro-trial-expired"]);
export{Fg,W7t,sis};
