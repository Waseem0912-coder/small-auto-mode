// @bun @bytecode
// (c) Anthropic PBC. All rights reserved. Use is subject to the Legal Agreements outlined here: https://code.claude.com/docs/en/legal-and-compliance.

// Version: 2.1.323
import{dt}from"/$bunfs/root/chunk-a6b2ht67.js";import{a}from"/$bunfs/root/chunk-zfpk8qec.js";import{Qe}from"/$bunfs/root/chunk-wzy8gy9y.js";var e="claudecode/editResult",l="1";function Fzo(o,t){return o===dt&&Qe(t)&&t[e]===l}async function $zo(o,t){if(o.isError===!0||t.subagentFrameResult===void 0)return o;try{if(await t.subagentFrameResultHolds?.()===!1)return o}catch(r){return a(r),o}return{...o,_meta:{...o._meta,[e]:t.subagentFrameResult}}}
export{Fzo,$zo};
