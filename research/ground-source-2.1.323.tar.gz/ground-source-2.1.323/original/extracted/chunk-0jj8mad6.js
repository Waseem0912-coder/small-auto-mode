// @bun @bytecode
// (c) Anthropic PBC. All rights reserved. Use is subject to the Legal Agreements outlined here: https://code.claude.com/docs/en/legal-and-compliance.

// Version: 2.1.323
import{i}from"/$bunfs/root/chunk-3nae1zmb.js";import{homedir as s}from"os";import{join as o}from"path";function r(e){return{env:e?.env??process.env,home:e?.homedir??i.HOME??s()}}function Xfa(e){let{env:n,home:t}=r(e);return n.XDG_STATE_HOME??o(t,".local","state")}function Jfa(e){let{env:n,home:t}=r(e);return n.XDG_CACHE_HOME??o(t,".cache")}function art(e){let{env:n,home:t}=r(e);return n.XDG_DATA_HOME??o(t,".local","share")}function zUe(e){return o(art(e),"claude","versions")}function fre(e){let{home:n}=r(e);return o(n,".local","bin")}
export{Xfa,Jfa,art,zUe,fre};
