// @bun @bytecode
// (c) Anthropic PBC. All rights reserved. Use is subject to the Legal Agreements outlined here: https://code.claude.com/docs/en/legal-and-compliance.

// Version: 2.1.323
import{t}from"/$bunfs/root/chunk-jw9em5g5.js";import{Sl}from"/$bunfs/root/chunk-13w6644x.js";import{Kt}from"/$bunfs/root/chunk-qxb2gr8e.js";import{TMt}from"/$bunfs/root/chunk-qjsswa8h.js";function tbi(){return!Kt()}function nIt(o){return o.filter((r)=>!r.mcpErrorMetadata&&!r.statusOnly&&!r.startupFatal)}function rIt(o){let r=[],i=[];for(let n of o)(n.statusOnly?r:i).push(n);return{statusNotices:r,invalidEntries:i}}function oIt(o){for(let r of o)t(`Invalid setting skipped without dialog (automated session): ${Sl(TMt(r.file))}: ${r.path}: ${r.message}`,{level:"error"})}
export{tbi,nIt,rIt,oIt};
